"""
Sanny AI — Backend completo
Auth JWT · Chat com memória · Free/Pro · Stripe · Dashboard
"""

import hashlib, hmac, json, os, secrets, sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import jwt, requests
from anthropic import Anthropic
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from passlib.context import CryptContext
from pydantic import BaseModel

load_dotenv()

ANTHROPIC_KEY  = os.getenv("ANTHROPIC_API_KEY", "")
STRIPE_SECRET  = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK = os.getenv("STRIPE_WEBHOOK_SECRET", "")
STRIPE_PRICE   = os.getenv("STRIPE_PRICE_ID", "")
JWT_SECRET     = os.getenv("JWT_SECRET", secrets.token_hex(32))
APP_URL        = os.getenv("APP_URL", "http://localhost:8000")
DB_PATH        = os.getenv("DB_PATH", "sanny.db")

FREE_LIMIT = 10
PRO_LIMIT  = 500

ai     = Anthropic(api_key=ANTHROPIC_KEY) if ANTHROPIC_KEY else None
pwd    = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer = HTTPBearer(auto_error=False)

app = FastAPI(title="Sanny AI", version="1.0.0", docs_url=None, redoc_url=None)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

Path("static").mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

SYSTEM_PROMPT = """Você é Sanny, uma inteligência artificial especialista em mercado financeiro \
brasileiro e global. Você é direta, precisa e nunca genérica.

IDIOMA: Detecte o idioma da primeira mensagem do usuário e mantenha-o em toda a conversa. \
Se o usuário mudar de idioma, acompanhe imediatamente.

MEMÓRIA: Você lembra de tudo nesta conversa. Referencie o que foi dito antes quando relevante.

ESPECIALIDADES — Mercado BR: B3, Ibovespa, FIIs, BDRs, Tesouro Direto, CDB, LCI, LCA, renda \
variável. Mercado global: NYSE, NASDAQ, ETFs, ADRs. Finanças pessoais: orçamento, reserva de \
emergência, planejamento de investimentos. Análise: técnica e fundamentalista quando relevante. \
Tributação BR: IR em ações, isenção de FIIs para PF, come-cotas, ganho de capital.

COMPORTAMENTO: Nunca recomende compra ou venda específica. Nunca invente preços ou dados — se \
perguntar cotação atual, oriente a verificar na corretora. Se não souber, diga claramente. \
Sempre lembre que suas análises são informativas, não consultoria financeira registrada.

FORMATO: Use markdown (listas, tabelas, negrito, blocos de código) quando ajudar a clareza. \
Seja conciso mas completo. Não repita informação já dada na conversa."""


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            plan TEXT NOT NULL DEFAULT 'free',
            stripe_customer TEXT,
            stripe_sub TEXT,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL DEFAULT 'Nova conversa',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conv_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (conv_id) REFERENCES conversations(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS daily_usage (
            user_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            count INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (user_id, day),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        """)


@app.on_event("startup")
def startup():
    init_db()


# ── helpers ──────────────────────────────────────────────────────────────────

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def today():
    return date.today().isoformat()

def make_jwt(uid: int) -> str:
    return jwt.encode(
        {"sub": str(uid), "exp": datetime.now(timezone.utc) + timedelta(days=30)},
        JWT_SECRET, algorithm="HS256"
    )

def decode_jwt(token: str) -> int:
    try:
        return int(jwt.decode(token, JWT_SECRET, algorithms=["HS256"])["sub"])
    except Exception:
        raise HTTPException(401, "Token inválido ou expirado")

def get_user(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if not creds:
        raise HTTPException(401, "Autenticação necessária")
    uid = decode_jwt(creds.credentials)
    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        raise HTTPException(401, "Usuário não encontrado")
    return dict(row)

def usage_today(uid: int) -> int:
    with db() as conn:
        row = conn.execute(
            "SELECT count FROM daily_usage WHERE user_id = ? AND day = ?", (uid, today())
        ).fetchone()
    return row["count"] if row else 0

def bump_usage(uid: int):
    with db() as conn:
        conn.execute(
            "INSERT INTO daily_usage (user_id, day, count) VALUES (?, ?, 1) "
            "ON CONFLICT(user_id, day) DO UPDATE SET count = count + 1",
            (uid, today())
        )

def daily_limit(plan: str) -> int:
    return PRO_LIMIT if plan == "pro" else FREE_LIMIT


# ── models ────────────────────────────────────────────────────────────────────

class RegisterIn(BaseModel):
    email: str
    name: str
    password: str

class LoginIn(BaseModel):
    email: str
    password: str

class MessageIn(BaseModel):
    content: str


# ── auth ──────────────────────────────────────────────────────────────────────

@app.post("/auth/register", status_code=201)
def register(body: RegisterIn):
    if len(body.password) < 6:
        raise HTTPException(400, "Senha deve ter no mínimo 6 caracteres")
    email = body.email.lower().strip()
    with db() as conn:
        try:
            conn.execute(
                "INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)",
                (email, body.name.strip(), pwd.hash(body.password), now_iso())
            )
            uid = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
        except sqlite3.IntegrityError:
            raise HTTPException(400, "Este e-mail já está cadastrado")
    return {"token": make_jwt(uid)}

@app.post("/auth/login")
def login(body: LoginIn):
    with db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE email = ?", (body.email.lower().strip(),)
        ).fetchone()
    if not row or not pwd.verify(body.password, row["password_hash"]):
        raise HTTPException(401, "E-mail ou senha incorretos")
    return {"token": make_jwt(row["id"])}

@app.get("/auth/me")
def me(user=Depends(get_user)):
    used  = usage_today(user["id"])
    limit = daily_limit(user["plan"])
    return {
        "id": user["id"], "email": user["email"], "name": user["name"],
        "plan": user["plan"],
        "usage": {"today": used, "limit": limit, "remaining": max(0, limit - used)}
    }


# ── conversations ─────────────────────────────────────────────────────────────

@app.post("/conversations", status_code=201)
def create_conv(user=Depends(get_user)):
    n = now_iso()
    with db() as conn:
        conn.execute(
            "INSERT INTO conversations (user_id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (user["id"], "Nova conversa", n, n)
        )
        cid = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    return {"id": cid, "title": "Nova conversa", "created_at": n}

@app.get("/conversations")
def list_convs(user=Depends(get_user)):
    with db() as conn:
        rows = conn.execute(
            "SELECT id, title, created_at, updated_at FROM conversations "
            "WHERE user_id = ? ORDER BY updated_at DESC LIMIT 40",
            (user["id"],)
        ).fetchall()
    return {"conversations": [dict(r) for r in rows]}

@app.get("/conversations/{cid}/messages")
def get_msgs(cid: int, user=Depends(get_user)):
    with db() as conn:
        if not conn.execute(
            "SELECT 1 FROM conversations WHERE id = ? AND user_id = ?", (cid, user["id"])
        ).fetchone():
            raise HTTPException(404, "Conversa não encontrada")
        rows = conn.execute(
            "SELECT role, content, created_at FROM messages WHERE conv_id = ? ORDER BY id",
            (cid,)
        ).fetchall()
    return {"messages": [dict(r) for r in rows]}


# ── chat ──────────────────────────────────────────────────────────────────────

@app.post("/conversations/{cid}/messages")
def send_msg(cid: int, body: MessageIn, user=Depends(get_user)):
    if not ai:
        raise HTTPException(500, "ANTHROPIC_API_KEY não configurada")
    if not body.content.strip():
        raise HTTPException(400, "Mensagem não pode estar vazia")

    with db() as conn:
        conv = conn.execute(
            "SELECT * FROM conversations WHERE id = ? AND user_id = ?", (cid, user["id"])
        ).fetchone()
    if not conv:
        raise HTTPException(404, "Conversa não encontrada")

    used  = usage_today(user["id"])
    limit = daily_limit(user["plan"])
    if used >= limit:
        raise HTTPException(
            429,
            f"Limite diário de {limit} mensagens atingido."
            + ("" if user["plan"] == "pro" else " Faça upgrade para Pro.")
        )

    with db() as conn:
        history = conn.execute(
            "SELECT role, content FROM messages WHERE conv_id = ? ORDER BY id",
            (cid,)
        ).fetchall()

    msgs = [{"role": m["role"], "content": m["content"]} for m in history][-40:]
    msgs.append({"role": "user", "content": body.content.strip()})

    try:
        resp = ai.messages.create(
            model="claude-sonnet-4-6", max_tokens=2000,
            system=SYSTEM_PROMPT, messages=msgs
        )
        reply = resp.content[0].text
    except Exception as exc:
        raise HTTPException(500, f"Erro na IA: {exc}")

    n = now_iso()
    is_first = len(history) == 0
    title = body.content.strip()[:55] + ("…" if len(body.content) > 55 else "")

    with db() as conn:
        conn.execute(
            "INSERT INTO messages (conv_id, role, content, created_at) VALUES (?, 'user', ?, ?)",
            (cid, body.content.strip(), n)
        )
        conn.execute(
            "INSERT INTO messages (conv_id, role, content, created_at) VALUES (?, 'assistant', ?, ?)",
            (cid, reply, n)
        )
        if is_first:
            conn.execute(
                "UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?", (title, n, cid)
            )
        else:
            conn.execute("UPDATE conversations SET updated_at = ? WHERE id = ?", (n, cid))

    bump_usage(user["id"])
    new_used = used + 1

    return {
        "role": "assistant", "content": reply,
        "conv_title": title if is_first else None,
        "usage": {"today": new_used, "limit": limit, "remaining": max(0, limit - new_used)}
    }


# ── dashboard ─────────────────────────────────────────────────────────────────

@app.get("/dashboard")
def dashboard(user=Depends(get_user)):
    with db() as conn:
        total_convs = conn.execute(
            "SELECT COUNT(*) AS c FROM conversations WHERE user_id = ?", (user["id"],)
        ).fetchone()["c"]
        total_msgs = conn.execute(
            "SELECT COUNT(*) AS c FROM messages m "
            "JOIN conversations c ON m.conv_id = c.id "
            "WHERE c.user_id = ? AND m.role = 'user'",
            (user["id"],)
        ).fetchone()["c"]
        weekly = conn.execute(
            "SELECT day, count FROM daily_usage WHERE user_id = ? ORDER BY day DESC LIMIT 7",
            (user["id"],)
        ).fetchall()
        created = conn.execute(
            "SELECT created_at FROM users WHERE id = ?", (user["id"],)
        ).fetchone()["created_at"]

    used  = usage_today(user["id"])
    limit = daily_limit(user["plan"])
    return {
        "plan": user["plan"], "usage_today": used, "limit": limit,
        "total_conversations": total_convs, "total_messages": total_msgs,
        "weekly": [dict(r) for r in weekly],
        "member_since": created,
    }


# ── billing ───────────────────────────────────────────────────────────────────

@app.post("/billing/checkout")
def checkout(user=Depends(get_user)):
    if not STRIPE_SECRET or not STRIPE_PRICE:
        raise HTTPException(503, "Pagamento ainda não configurado. Configure STRIPE_SECRET_KEY e STRIPE_PRICE_ID.")
    try:
        r = requests.post(
            "https://api.stripe.com/v1/checkout/sessions",
            auth=(STRIPE_SECRET, ""),
            data={
                "mode": "subscription",
                "line_items[0][price]": STRIPE_PRICE,
                "line_items[0][quantity]": "1",
                "success_url": f"{APP_URL}?upgraded=1",
                "cancel_url": f"{APP_URL}",
                "customer_email": user["email"],
                "metadata[user_id]": str(user["id"]),
            },
            timeout=15
        )
        r.raise_for_status()
        return {"url": r.json()["url"]}
    except Exception as exc:
        raise HTTPException(500, f"Erro ao criar sessão Stripe: {exc}")

@app.post("/billing/webhook")
async def webhook(request: Request):
    payload = await request.body()
    sig     = request.headers.get("stripe-signature", "")

    if STRIPE_WEBHOOK:
        try:
            parts = dict(item.split("=", 1) for item in sig.split(","))
            signed = f"{parts['t']}.{payload.decode()}"
            expected = hmac.new(
                STRIPE_WEBHOOK.encode(), signed.encode(), hashlib.sha256
            ).hexdigest()
            if not hmac.compare_digest(expected, parts.get("v1", "")):
                raise HTTPException(400, "Assinatura inválida")
        except HTTPException:
            raise
        except Exception:
            raise HTTPException(400, "Erro ao verificar webhook")

    try:
        event = json.loads(payload)
    except Exception:
        raise HTTPException(400, "Payload inválido")

    if event.get("type") == "checkout.session.completed":
        s      = event["data"]["object"]
        uid    = s.get("metadata", {}).get("user_id")
        sub_id = s.get("subscription")
        if uid:
            with db() as conn:
                conn.execute(
                    "UPDATE users SET plan='pro', stripe_sub=? WHERE id=?",
                    (sub_id, int(uid))
                )
    return {"ok": True}


# ── frontend ──────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "ai": ai is not None}

@app.get("/")
@app.get("/{path:path}")
def frontend():
    p = Path("static/index.html")
    return FileResponse(str(p)) if p.exists() else JSONResponse({"error": "Frontend não encontrado"})
